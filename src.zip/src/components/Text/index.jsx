export const Text=({count})=>{
    return(
        <p>The count is {count}</p>
    )
}