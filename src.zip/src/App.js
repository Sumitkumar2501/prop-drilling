import { useState } from 'react';
import './App.css';
import { Button } from "./components/Button";
function App() {

  const [count,setCount]=useState(0);

  const onButtonClick=()=>{
    setCount(count+1);
  }

  return (
    <div className="App">
      <Button count={count} onButtonClick={onButtonClick}/>
    </div>
  );
}

export default App;
